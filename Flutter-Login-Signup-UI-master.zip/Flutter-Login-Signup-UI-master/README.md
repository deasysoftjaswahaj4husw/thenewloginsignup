# Flutter Login Signup UI Demo

### :heart: Found this project useful?

If you found this project useful, then please consider giving it a :star: on Github and sharing it with your friends via social media.

## Project Created & Maintained By

### Sheraz Mahar
A sample app to showcase login-signup app using flutter. 

# Demo
<img height="480px" width="270px" src="https://github.com/flutter-devs/flutter_login-signup_demo/blob/master/screens/demo.gif">



# Android Screen
<img height="480px" src="https://github.com/flutter-devs/flutter_login-signup_demo/blob/master/screens/android1.png">  <img height="480px" src="https://github.com/flutter-devs/flutter_login-signup_demo/blob/master/screens/android2.png">


# iOS Screen
<img height="480px" src="https://github.com/flutter-devs/flutter_login-signup_demo/blob/master/screens/iphone1.png"> <img height="480px" src="https://github.com/flutter-devs/flutter_login-signup_demo/blob/master/screens/iphone2.png">


## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our 
[online documentation](https://flutter.dev/docs), which offers tutorials, 
samples, guidance on mobile development, and a full API reference.
